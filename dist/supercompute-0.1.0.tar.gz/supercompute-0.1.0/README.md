# SuperCompute Network

A **distributed compute scheduling system** with fault-tolerant task execution, adaptive scheduling, and a decentralized AI inference network. Backed by a Solana token economy.

```
                  ┌──────────────────────────────┐
                  │       Client / API            │
                  │  (curl, SDK, Web UI)          │
                  └────────────┬─────────────────┘
                               │ POST /tasks
                               ▼
                  ┌──────────────────────────────┐
                  │         Scheduler              │
                  │  Score-based / Round-Robin     │
                  │  Priority-aware queuing        │
                  │  Heartbeat monitoring          │
                  └────┬──────┬──────┬────────────┘
                       │      │      │
               ┌───────┘      │      └───────┐
               ▼              ▼              ▼
        ┌──────────┐  ┌──────────┐  ┌──────────┐
        │ Node-1   │  │ Node-2   │  │ Node-N   │
        │ Worker   │  │ Worker   │  │ Worker   │
        └────┬─────┘  └────┬─────┘  └────┬─────┘
             │             │             │
             └──────┬──────┘─────────────┘
                    ▼
          ┌──────────────────┐
          │  Result Store     │
          │  (completed /     │
          │   failed tasks)   │
          └──────────────────┘
```

**Two engines in one repo:**
- **Python Engine** (`supercompute/`) — Pure compute scheduling with adaptive scoring
- **Web Platform** (`app/`, `worker/`) — Next.js AI inference network with Solana tokenomics

---

## Features

**Compute Engine (Python)**
- ✅ **Distributed task scheduling** — Priority queue with 4 strategies (round-robin, random, least-loaded, score-based)
- ✅ **Adaptive scheduling** — Score = f(CPU load, queue length, failure rate)
- ✅ **Node failure recovery** — Heartbeat monitoring, dead node detection, automatic task reassignment
- ✅ **Task retry** — Configurable retry with exponential back-off
- ✅ **Structured logging** — JSON logging for production observability
- ✅ **CLI tool** — `supercompute start-cluster`, `supercompute submit`, `supercompute benchmark`
- ✅ **REST API** — FastAPI server for task submission and monitoring
- ✅ **Benchmark suite** — Throughput/latency measurement across cluster sizes
- ✅ **Test suite** — 12 unit + integration tests

**Web Platform (Next.js 16)**
- ✅ **Uncensored inference** — Chat, image generation via OpenAI-compatible API
- ✅ **Worker network** — Browser (WebGPU) + native (Ollama) workers
- ✅ **Solana tokenomics** — `$SUPER` staking, buyback/burn, USDC rewards
- ✅ **Keeper** — On-chain fee claiming + market operations

---

## Quick Start

### Compute Engine (Python)

```bash
# Install
pip install -r requirements.txt

# Run the demo
python examples/hello_world.py
# Output:
#   [Scheduler] task assigned to node-1
#   [node-1] executing task...
#   [result] 42

# Run tests
python tests/test_all.py

# Run benchmarks
python tests/benchmark.py

# CLI
python -m supercompute.cli start-cluster --nodes 5
```

### Web Platform

```bash
npm install
cp .env.local.example .env.local
npm run dev:all
```

---

## CLI Usage

```bash
# Start a local cluster with API server
supercompute start-cluster --nodes 5 --strategy score_based

# Submit a task script
supercompute submit my_task.py

# Show status
supercompute status

# Run benchmark
supercompute benchmark --nodes "1,2,4,8" --tasks 200
```

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/tasks` | Submit a task |
| `GET` | `/tasks/{id}` | Get task status |
| `GET` | `/tasks` | List recent tasks |
| `GET` | `/nodes` | List cluster nodes |
| `GET` | `/stats` | Cluster statistics |

**Submit a task:**
```bash
curl -X POST http://localhost:8080/tasks \
  -H "Content-Type: application/json" \
  -d '{"name": "my-task", "payload": {"data": 42}, "priority": 1}'
```

---

## Adaptive Scheduling

**Score-based** is the default and recommended strategy:

```python
score = α × cpu_load + β × queue_length + γ × failure_rate

Where:
  α = 0.5  (load factor weight)
  β = 0.3  (queue length weight)
  γ = 0.2  (failure rate penalty)
```

**Available strategies:**
| Strategy | Description |
|----------|-------------|
| `round_robin` | Even distribution across nodes |
| `random` | Random node selection |
| `least_loaded` | Pick node with lowest load |
| `score_based` | **Recommended** — weighted adaptive scoring |

---

## Architecture

```
supercompute/
├── supercompute/              Python compute engine
│   ├── core/                  Core abstractions
│   │   ├── task.py            Task model with retry/cancellation
│   │   ├── node.py            Node model with heartbeat/scoring
│   │   └── scheduler.py       Scheduler with 4 scheduling strategies
│   ├── network/               Communication layer
│   │   ├── rpc.py             Lightweight RPC client/server
│   │   └── transport.py       In-process + HTTP transport
│   ├── runtime/               Execution runtime
│   │   ├── cluster.py         Cluster lifecycle + heartbeat loop
│   │   └── worker.py          Worker process
│   ├── api/                   REST API (FastAPI)
│   │   └── server.py          Task submission, query, node list
│   ├── cli/                   Command-line interface
│   │   └── __init__.py        start-cluster, submit, benchmark
│   ├── config.py              YAML config loader
│   └── log_setup.py           Structured JSON logging
├── app/                       Next.js 16 Web UI
├── worker/                    Browser + native worker agent
├── lib/                       Orchestrator, keeper, on-chain
├── examples/                  Demo scripts
│   ├── hello_world.py         Minimal working example
│   └── adaptive_demo.py       Strategy comparison demo
├── tests/                     Test suite
│   ├── test_all.py            12 unit + integration tests
│   └── benchmark.py           Throughput/latency benchmark
└── config/                    Default YAML configuration
```

---

## Benchmark Results

Simulated throughput across cluster sizes (200 tasks per run):

```
 Nodes |   Throughput |  Avg Latency |  P99 Latency
-------+-------------+-------------+-------------
     1 |  34964 tasks/s |       0.02ms |       0.03ms
     2 |  34482 tasks/s |       0.02ms |       0.03ms
     4 |  33909 tasks/s |       0.02ms |       0.03ms
     8 |  32561 tasks/s |       0.02ms |       0.03ms
    16 |  30198 tasks/s |       0.03ms |       0.03ms
```

*Note: In-memory simulation. Real-world throughput depends on node performance and network latency.*

---

## Development Roadmap

### Phase 1 — Core MVP ✓
- [x] Task lifecycle (submit → queue → run → complete/fail)
- [x] Scheduler with 4 strategies
- [x] Node heartbeat + health tracking
- [x] Hello world demo

### Phase 2 — Engineering ✓
- [x] Failure recovery (dead node detection + task reassignment)
- [x] Task retry with configurable max retries
- [x] Structured JSON logging
- [x] YAML configuration system
- [x] CLI tool
- [x] REST API (FastAPI)
- [x] 12 automated tests

### Phase 3 — Productization ✓
- [x] Benchmark suite
- [x] Architecture diagram
- [x] Multi-node cluster simulation
- [x] Full README

### Phase 4 — Innovation
- [ ] GPU-aware scheduling (memory, CUDA cores)
- [ ] LLM inference batching optimization
- [ ] Latency-aware edge/cloud routing
- [ ] Gossip protocol for P2P node discovery
- [ ] Real distributed transport (WebSocket/gRPC)

---

## Test Suite

```bash
$ python tests/test_all.py

🧪 SuperCompute Test Suite

  ✅ test_task_creation
  ✅ test_task_retry_limit
  ✅ test_node_heartbeat
  ✅ test_node_score
  ✅ test_node_task_tracking
  ✅ test_scheduler_submit
  ✅ test_scheduler_schedule
  ✅ test_scheduler_complete
  ✅ test_scheduler_fail_retry
  ✅ test_dead_node_detection
  ✅ test_multiple_strategies
  ✅ test_cluster_submit

Results: 12 passed, 0 failed, 12 total
```

---

## License

MIT

---

## Join the Network

- **Use AI** — Visit [supercompute.ai](https://supercompute.ai)
- **Run a Worker** — `npm run start:worker` on any machine with a GPU
- **Stake $SUPER** — Earn USDC rewards from network revenue
- **Contribute** — PRs welcome!
